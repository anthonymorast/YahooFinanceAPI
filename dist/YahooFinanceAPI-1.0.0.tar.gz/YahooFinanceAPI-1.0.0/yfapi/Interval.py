class Interval:
    WEEKLY = '1wk'
    MONTHLY = '1mo'
    DAILY = '1d'

if __name__ == '__main__':
    print(Interval.WEEKLY)
    print(Interval.MONTHLY)
    print(Interval.DAILY)
